﻿contour_1_new_fix bundle
========================

Вміст:
- c/contour_1_new_fix — остання C-версія Контуру 1 (new_fix) після зауважень
- sim_stand_new_fix — стенд на цій C-бібліотеці + зібрані дані та результати

Ключові результати (тест 250 кадрів, eps=0.05):
- S5 mAP@0.5 = 0.578, FPS = 5.41
- S5 vs S4 (рівна точність, ci_s4): перевага FPS 86.7 % (95% ДІ 80.4–92.3 %)
Файли: sim_stand_new_fix/analyze_out.txt, ci_s4_out.txt, collect_log.txt

Збірка C (MinGW):
  cd c/contour_1_new_fix
  mingw32-make all
  mingw32-make test

Стенд (з PYTHONUTF8=1 на Windows):
  cd sim_stand_new_fix
  python analyze.py 0.05
  python ci_s4.py
  python fit_blur.py check
